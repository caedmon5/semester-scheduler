from datetime import time

schedule = [
    # ☀️ Summer 2025 — Monday
    ("Newspaper Reading", 0, time(6, 30), time(8, 0), True, "Personal", True),
    ("Shower / Dog Walk / Breakfast", 0, time(8, 0), time(9, 30), True, "Personal", True),
    ("Student Draft Review", 0, time(9, 30), time(11, 30), True, "Supervision", False),
    ("Email Triage", 0, time(11, 30), time(12, 0), True, "Office", False),
    ("Lunch", 0, time(12, 0), time(13, 0), True, "Personal", True),
    ("Reading", 0, time(13, 0), time(14, 30), True, "Research", False),
    ("Lab Meeting", 0, time(15, 0), time(16, 0), True, "Supervision", False),
    ("BOOKABLE Follow-up / Admin", 0, time(16, 0), time(17, 0), False, "Office", False),

    # Tuesday
    ("Newspaper Reading", 1, time(6, 30), time(8, 0), True, "Personal", True),
    ("Shower / Dog Walk / Breakfast", 1, time(8, 0), time(9, 30), True, "Personal", True),
    ("Creative Writing / Projects", 1, time(9, 30), time(11, 30), True, "Research", False),
    ("Light Admin / Email", 1, time(11, 30), time(12, 0), True, "Office", False),
    ("Lunch", 1, time(12, 0), time(13, 0), True, "Personal", True),
    ("Focus", 1, time(13, 0), time(15, 0), True, "Research", False),
    ("Reading", 1, time(15, 0), time(17, 0), True, "Research", False),

    # Wednesday
    ("Newspaper Reading", 2, time(6, 30), time(8, 0), True, "Personal", True),
    ("Shower / Kennel Drop-off / Breakfast", 2, time(8, 0), time(9, 30), True, "Personal", True),
    ("Bookable Grad student 1:1", 2, time(10, 0), time(12, 0), True, "Supervision", False),
    ("Lunch", 2, time(12, 0), time(13, 0), True, "Personal", True),
    ("Reading", 2, time(13, 0), time(14, 30), True, "Research", False),
    ("BOOKABLE Admin / Planning / Journal", 2, time(15, 0), time(17, 0), False, "Office", False),

    # Thursday
    ("Newspaper Reading", 3, time(6, 30), time(8, 0), True, "Personal", True),
    ("Shower / Dog Walk / Breakfast", 3, time(8, 0), time(9, 30), True, "Personal", True),
    ("Research Reading / Project Prep", 3, time(9, 30), time(11, 30), True, "Research", False),
    ("Lunch", 3, time(12, 0), time(13, 0), True, "Personal", True),
    ("BOOKABLE Overflow Meetings / Follow-up", 3, time(13, 0), time(15, 0), False, "Office", False),
    ("Decompression", 3, time(15, 0), time(17, 0), True, "Personal", True),

    # Friday
    ("Newspaper Reading", 4, time(6, 30), time(8, 0), True, "Personal", True),
    ("Shower / Kennel Drop-off / Breakfast", 4, time(8, 0), time(9, 30), True, "Personal", True),
    ("BOOKABLE Grad Student Overflow / Admin", 4, time(10, 0), time(12, 0), False, "Supervision", False),
    ("Lunch", 4, time(12, 0), time(13, 0), True, "Personal", True),
    ("BOOKABLE Admin Wrap-up / Task Review", 4, time(13, 0), time(15, 0), False, "Office", False),
    ("Rest / Decompression", 4, time(15, 0), time(17, 0), True, "Personal", True),
]
